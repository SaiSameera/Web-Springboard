﻿angular.module("wiproApp")
    .controller("dashboardController", function ($scope, dashboardService, $location, $state, $window, $rootScope) {
        "use strict";
        $scope.byDemandSourceList = [];
        $scope.byDemandClassificationList = [];
        $scope.byDemandStatusList = [];

        $scope.byOppurtunityStatusList = [];
        $scope.byOppurtunityClassificationList = [];
        $scope.byOppurtunityCategoryList = [];

        // Gets the getDemandSourceData
        $scope.getDemandSourceData = function () {
            dashboardService.getDemandSourceData().success(function (data) {
                $scope.byDemandSourceList = data.slice(0,3);
            }).error(function (err) {
                return;
            });
        };
        
        // Gets the getDemandClassificationData
        $scope.getDemandClassificationData = function () {
            dashboardService.getDemandClassificationData().success(function (data) {
                $scope.byDemandClassificationList = data.slice(0,2);
            }).error(function (err) {
                return;
            });
        };

        // Gets the getDemandStatusData
        $scope.getDemandStatusData = function () {
            dashboardService.getDemandStatusData().success(function (data) {
                $scope.byDemandStatusList = data.filter(function (item) {
                    return item.Key == "Open" || item.Key == "Hold" || item.Key == "Identified";
                });
            });
            };

            // Gets the getOppurtunityClassificationData
            $scope.getOppurtunityClassificationData = function () {
                dashboardService.getOppurtunityClassificationData().success(function (data) {
                    $scope.byOppurtunityClassificationList = data.slice(0,2);
                }).error(function (err) {
                    return;
                });
            };

            // Gets the getOppurtunityCategoryData
            $scope.getOppurtunityCategoryData = function () {
                dashboardService.getOppurtunityCategoryData().success(function (data) {
                    $scope.byOppurtunityCategoryList = data.slice(0,2);
                }).error(function (err) {
                    return;
                });

                // Gets the getOppurtunityStatusData
                //$scope.getOppurtunityStatusData = function () {
                //  dashboardService.getOppurtunityStatusData().success(function (data) {
                //    $scope.byOppurtunityStatusList = data;
                //}).error(function (err) {
                //  return;
                //});
                //};


            };
        });